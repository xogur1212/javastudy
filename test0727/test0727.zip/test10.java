package test0727;

import java.util.Scanner;

public class test10 {
	public static void main(String[] args) {
		
	for(int i=1;i<100;i++) {
		if(i%3==0) {
			System.out.println(i+ " 박수 짞");
		}
	}
	}
}
